package com.praveen.E_commers_Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommersApplicationTests {

	@Test
	void contextLoads() {
	}

}
